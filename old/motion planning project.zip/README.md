# Robot-navigation-in-crowds
Use reinforcement learning

