from GameClass import GameClass
import numpy as np
import random
import csv
from nn import neural_net, LossHistory
import os.path
import timeit
from keras.utils import plot_model


TUNING = False
GAMMA = 0.9
NUM_INPUT = 5
FPS = 60

def train(model, params):
    EPISODE = 100
    FRAMES = 2000
    epsilon = 1
    batchSize = params['batchSize']
    buffer = params['buffer']
    replay = []

    for m in range(EPISODE):
        gameObject = GameClass(draw_screen = False, display_path = False, fps = FPS)

        # Choose no action in the initial frame
        action = 2
        reward, state = gameObject.frame_step(action) 
        for t in range(FRAMES):
            # Let's run our Q function on (state,action) to get Q values for all possible actions
            Q = np.zeros(3)
            for a in range(3):
                features = get_features(state,a)
                Q.append(model.predict(features, batch_size=batchSize))

            # Choose the action based on the epsilon greedy algorithm
            if (random.random() < epsilon):  # choose random action
                action = np.random.randint(0, 3)
            else:  # choose best action from Q(s,a) values
                action = (np.argmax(Q))

            # Execute the action, observe new state and reward
            reward, state_new = gameObject.frame_step(action)

            # Store the (state, action, reward, new state) pair in the replay
            memory = state, action, reward, state_new
            replay.append(memory)

            # If we've stored enough in our buffer, pop the oldest.
            if len(replay) > buffer:
                replay.pop(0)

            # Randomly sample our experience replay memory
            minibatch = random.sample(replay, batchSize)

            # Process the minibatch to get the training data
            X_train, y_train = process_minibatch(minibatch,model,batchSize)

            # Train the model on this batch.
            model.fit(X_train, y_train, batch_size=batchSize,verbose=1)
            
            # Decrement epsilon over time.
            if epsilon > 0.1:
                epsilon -= 1.0/FRAMES

            # Update the starting state with S'.
            state = state_new

            # Stop this episode if we achieved the goal
            if gameObject.check_reach_goal():
                break

    return model

# The features are [state,encoded action]
def get_features(state, action):
    # encode the action into a 3 element vector [1,0,0],[0,1,0], or[0,0,1]
    action_enc = np.zeros(3)
    action_enc[action] = 1
    features = np.hstack((state, action_enc))
    return features

def process_minibatch(minibatch, model,batchSize):
    features_batch = []
    target_batch = []
    for mem in minibatch:
        state, action, reward, state_new = mem

        features_batch.append(get_features(state,action))

        Q = np.zeros(3)
        for a in range(3):
            features=get_features(state_new,a)
            Q.append(model.predict(features, batch_size=batchSize))
        maxQ = np.max(Q)

        # Check for terminal state.
        if reward > 8000:  # non-terminal state
            target = (reward + (GAMMA * maxQ))
        else:  # terminal state
            target = reward

        target_batch.append(target)

    return features_batch, target_batch

if __name__ == "__main__":
        nn_param = [256, 256]
        params = {
            "batchSize": 40,
            "buffer": 10000,
            "nn": nn_param
        }
        model = neural_net(NUM_INPUT, nn_param)
        model = train(model, params)
        plot_model(model, to_file='saved-models/model_nn_01.png')
        model.save('saved-models/model_nn_01.h5', overwrite=True)
        del model
